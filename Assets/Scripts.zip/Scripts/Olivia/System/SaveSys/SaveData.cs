using UnityEngine;

[System.Serializable]
public class SaveData
{
    public int currentAct = 1;
}
