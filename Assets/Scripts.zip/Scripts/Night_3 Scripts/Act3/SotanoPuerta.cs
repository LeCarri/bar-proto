using UnityEngine;

public class PuertaSotano : MonoBehaviour
{
    public void Interact()
    {
        Debug.Log("Entrando al s�tano");

        if (Act3Manager.Instance != null)
        {
            Act3Manager.Instance.IrASotano();
        }
    }
}